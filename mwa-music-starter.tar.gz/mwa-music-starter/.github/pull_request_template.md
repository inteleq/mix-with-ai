## What changed and why

## Verification

- [ ] `npm run verify` passes.
- [ ] Tests use fixtures and make no paid generation requests.
- [ ] No credentials, signed URLs, private prompts, or unrelated implementation code are included.
