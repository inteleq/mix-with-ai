---
name: Bug report
about: Report a reproducible problem with the starter or client
---

**Expected behavior**

**What happened**

**How to reproduce**

**Node version and operating system**

**Preview or live mode?**

Include a public error code if available. Remove keys, private prompts, identifiers, and signed URLs before posting.
